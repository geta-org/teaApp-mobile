import TeaIcone from './TeaIcon.svg'
import { IconContainer } from './styles'
export function TeaIcon () {
  return (
    <IconContainer>
      <TeaIcone />
    </IconContainer>
  )
}